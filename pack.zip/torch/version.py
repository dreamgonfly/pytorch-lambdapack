__version__ = '0.3.0.post4'
debug = False
cuda = None
